﻿using Framework.Models;
using Framework.Models.Chart;
using System.Data;

namespace $safeprojectname$
{
    public interface IChart : IDataAccess<FilterPanelMenu, ChartInfo>
    {
        DataSet GetOutputDataTable(params object[] param);
    }
}
