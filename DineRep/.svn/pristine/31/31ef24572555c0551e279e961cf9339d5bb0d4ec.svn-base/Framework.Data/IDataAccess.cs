﻿using NextGen.Core.Models;
using System;

namespace $safeprojectname$
{
    public interface IDataAccess<Menu, Output> : IDisposable
    {
        Menu GetMenu();
        Output GetOutputData(ViewConfiguration config, params object[] param);
    }
}
