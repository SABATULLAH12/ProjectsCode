﻿using Framework.Models;
using Framework.Models.Table;

namespace $safeprojectname$
{
    public interface ITable : IDataAccess<FilterPanelMenu, TableInfo>
    {
    }
}
