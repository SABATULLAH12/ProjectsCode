﻿using System.Collections.Generic;

namespace $safeprojectname$.Chart
{
    public class ChartInfo
    {
        public IList<ChartSeries> Series { get; set; }
    }
}