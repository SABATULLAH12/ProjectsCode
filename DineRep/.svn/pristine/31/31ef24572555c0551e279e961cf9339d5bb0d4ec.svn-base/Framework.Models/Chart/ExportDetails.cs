﻿
namespace $safeprojectname$.Chart
{
    public class ExportDetails
    {
        public string ChartType { get; set; }
        public FilterPanelInfo[] Filter { get; set; }
    }
}