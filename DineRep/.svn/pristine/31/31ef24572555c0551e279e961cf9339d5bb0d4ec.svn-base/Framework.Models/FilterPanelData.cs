﻿namespace $safeprojectname$
{
    public class FilterPanelData
    {
        public object ID { get; set; }
        public string Text { get; set; }
    }
}
