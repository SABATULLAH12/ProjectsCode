﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public class TimePeriod
    {
        public string Interval { get; set; }
        public IList<TimeperiodYear> Years { get; set; }
    }
}
