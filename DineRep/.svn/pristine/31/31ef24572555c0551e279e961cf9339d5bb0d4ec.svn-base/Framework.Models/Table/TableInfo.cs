﻿namespace $safeprojectname$.Table
{
    public class TableInfo
    {
        public VTable Table { get; set; }
    }
}