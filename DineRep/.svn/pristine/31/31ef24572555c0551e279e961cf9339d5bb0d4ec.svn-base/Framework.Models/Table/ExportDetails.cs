﻿namespace $safeprojectname$.Table
{
    public class ExportDetails
    {
    }
}