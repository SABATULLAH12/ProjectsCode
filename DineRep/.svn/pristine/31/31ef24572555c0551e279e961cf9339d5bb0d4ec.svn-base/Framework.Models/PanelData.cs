﻿using System;

namespace $safeprojectname$
{
    public class PanelData
    {
        public string Text { get; set; }
        public object _ID { get; set; }
        public string ID
        {
            get
            {
                if (_ID != null) return Convert.ToString(_ID);
                else return null;
            }
            set { _ID = value; }
        }
        public object _ParentID { get; set; }
        public string ParentID
        {
            get
            {
                if (_ParentID == null)
                    return null;
                else
                    return Convert.ToString(_ParentID);
            }
            set { _ParentID = value; }
        }
        public string ParentText { get; set; }
        public int ChildCount { get; set; }

        public bool IsSelectable { get; set; }
    }
}
