﻿
namespace $safeprojectname$.Snapshot
{
    public class Widgets
    {
        public int WidgetId { get; set; }
        public string WidgetName { get; set; }
    }
}