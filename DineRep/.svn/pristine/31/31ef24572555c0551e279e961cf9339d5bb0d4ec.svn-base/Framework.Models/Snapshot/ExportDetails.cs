﻿namespace $safeprojectname$.Snapshot
{
    public class ExportDetails
    {
        public string Base64 { get; set; }
    }
}