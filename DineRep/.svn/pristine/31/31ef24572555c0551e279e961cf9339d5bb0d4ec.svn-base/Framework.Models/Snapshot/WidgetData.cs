﻿namespace $safeprojectname$.Snapshot
{
    public class WidgetData
    {
        public string Label { get; set; }
        public object Data { get; set; }
    }
}