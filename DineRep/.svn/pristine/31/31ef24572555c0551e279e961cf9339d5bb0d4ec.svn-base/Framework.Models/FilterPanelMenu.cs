﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public class FilterPanelMenu
    {
        public ICollection<PanelInfo> Filter { get; set; }
    }
}
