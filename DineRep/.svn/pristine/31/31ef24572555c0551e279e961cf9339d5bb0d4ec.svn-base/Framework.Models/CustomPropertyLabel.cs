﻿namespace $safeprojectname$
{
    public class CustomPropertyLabel
    {
        public string UserType { get; set; }
        public string WidgetName { get; set; }
    }
}
