﻿namespace $safeprojectname$
{
    public class FilterPanelInfo
    {
        public FilterPanelData[] Data { get; set; }
    }
}
