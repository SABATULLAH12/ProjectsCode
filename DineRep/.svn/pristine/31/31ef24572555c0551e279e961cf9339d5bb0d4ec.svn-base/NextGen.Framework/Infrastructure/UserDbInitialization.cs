﻿using NextGen.Core.Data;

namespace $safeprojectname$.Infrastructure
{
    internal class UserDbInitialization
    {
        public void DefaultUser()
        {
            UserDbContext user = new UserDbContext();
            user.DefaultUsers();
        }
    }
}