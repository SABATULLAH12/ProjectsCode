﻿/// <reference path="angular.min.js" />
/// <reference path="jquery-2.2.3.min.js" />
/// <reference path="master-theme.js" />

angular.module("mainApp").controller("homeController", ["$scope", "$http", function ($scope) {
    $scope.landing = {
    }
}]);