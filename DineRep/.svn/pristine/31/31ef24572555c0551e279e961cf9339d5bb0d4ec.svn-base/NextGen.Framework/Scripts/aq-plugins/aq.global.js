﻿var AqLeftPanel = { Url: '' };
