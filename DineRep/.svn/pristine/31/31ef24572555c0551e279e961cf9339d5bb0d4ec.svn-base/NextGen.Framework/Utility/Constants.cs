﻿
namespace $safeprojectname$.Utility
{
    public class Constants
    {
        #region session
        public class Session
        {
            public const string ActiveUser = "ActiveUser";
        }
        #endregion

        #region fields
        public const string ToolTitlePrefix = "Tool :: ";
        #endregion
    }
}